/*
 * rtc_mon_1.h
 *
 *  Created on: Feb 26, 2019
 *      Author: Luan_Pham
 */
#include "main.h"
#ifndef RTC_MON_1_H_
#define RTC_MON_1_H_


void RTC_Mon(RTC_TimeTypeDef* sTime);
#endif /* RTC_MON_1_H_ */
