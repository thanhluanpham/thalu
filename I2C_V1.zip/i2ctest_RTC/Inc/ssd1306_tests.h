#ifndef __SSD1306_TEST_H__
#define __SSD1306_TEST_H__

void ssd1306_TestBorder();
void ssd1306_TestFonts();
void ssd1306_TestFPS();
void ssd1306_TestAll();

#endif // __SSD1306_TEST_H__
